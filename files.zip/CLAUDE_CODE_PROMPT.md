# NOSARA COLLECTIVE CONSCIENCE — Claude Code Migration Prompt

---

## CONTEXT — READ THIS FIRST

You are migrating an existing luxury hospitality web app to a 
production-ready platform.

I am providing you with:
1. `index.html` — 230KB single-page app, fully functional
2. This prompt

The existing app has:
- Shopping cart system (add properties + services)
- 9 property galleries with Cloudinary images
- iCal sync with Airbnb (7 properties connected)
- Concierge builder (22 services with price calculator)
- Retreat section
- Surf forecast
- Real estate lots
- Collective Guide (4 tabs)
- Wise + PayPal payment modal
- WhatsApp floating button
- Scroll animations + marquee ticker

**DO NOT lose any existing functionality or visual design.**
The current design is premium, minimal, surf/skate retro luxury.
Preserve all colors, fonts, and animations exactly.

Cloudinary account: cloud name `dzqgajn3l` (images already uploaded)

---

## BUSINESS MODEL

- Property nightly rates as listed
- **Owner receives: nightly rate minus 10%**
- **5% → Nosara community families (direct, transparent)**
- **5% → Nosara Collective Conscience operations**
- 5% community impact shown at checkout — NOT added to guest price
- Taxes: 13% IVA (Costa Rica)

---

## PHASE 1 ONLY — Build this now

> Focus: make real bookings and payments work.
> Do NOT build Phase 2 features yet.

### 1. Project Structure

Convert to:
```
nosara-collective/
├── index.html          (existing, preserve)
├── src/
│   ├── components/     (extract JS components)
│   ├── lib/
│   │   ├── supabase.js
│   │   ├── paypal.js
│   │   ├── wise.js
│   │   └── ical.js
│   └── styles/
├── netlify/
│   └── functions/
│       ├── create-reservation.js
│       ├── paypal-webhook.js
│       ├── check-availability.js
│       └── send-confirmation.js
├── public/
├── .env.example
├── netlify.toml
└── README.md
```

### 2. Supabase Database

Create these tables:

```sql
-- Properties
CREATE TABLE properties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  price_per_night INTEGER NOT NULL,
  max_guests INTEGER,
  bedrooms INTEGER,
  bathrooms INTEGER,
  description TEXT,
  cover_image TEXT,
  images JSONB,
  features JSONB,
  airbnb_ical_url TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Reservations
CREATE TABLE reservations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference TEXT UNIQUE NOT NULL,
  property_id UUID REFERENCES properties(id),
  guest_name TEXT NOT NULL,
  guest_email TEXT NOT NULL,
  guest_phone TEXT,
  guest_country TEXT,
  check_in DATE NOT NULL,
  check_out DATE NOT NULL,
  nights INTEGER NOT NULL,
  num_guests INTEGER NOT NULL,
  accommodation_total INTEGER NOT NULL,
  taxes INTEGER NOT NULL,
  grand_total INTEGER NOT NULL,
  community_impact INTEGER NOT NULL,
  owner_payout INTEGER NOT NULL,
  company_allocation INTEGER NOT NULL,
  payment_method TEXT CHECK (payment_method IN ('paypal','wise')),
  payment_status TEXT DEFAULT 'pending' 
    CHECK (payment_status IN ('pending','paid','verified','cancelled','refunded')),
  paypal_order_id TEXT,
  wise_reference TEXT,
  wise_proof_url TEXT,
  services JSONB,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Blocked Dates (from Airbnb iCal + confirmed reservations)
CREATE TABLE blocked_dates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID REFERENCES properties(id),
  date DATE NOT NULL,
  source TEXT DEFAULT 'manual',
  reservation_id UUID REFERENCES reservations(id),
  UNIQUE(property_id, date)
);

-- Leads
CREATE TABLE leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT CHECK (type IN ('booking','retreat','real_estate','concierge','general')),
  name TEXT,
  email TEXT,
  phone TEXT,
  country TEXT,
  message TEXT,
  property_interest TEXT,
  budget TEXT,
  travel_dates TEXT,
  num_guests INTEGER,
  source TEXT,
  status TEXT DEFAULT 'new',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Concierge Requests
CREATE TABLE concierge_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reservation_id UUID REFERENCES reservations(id),
  guest_name TEXT,
  guest_email TEXT,
  services JSONB NOT NULL,
  total INTEGER,
  payment_status TEXT DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

Seed properties table with all 9 properties from index.html:
- Casa Arcilla No. 1 ($500/night)
- Casa Arcilla No. 2 ($450/night)
- Bundle: Arcilla 1+2 ($900/night)
- Casa Ojos Azules ($500/night)
- Casa Sol ($300/night)
- Casa Mar ($300/night)
- Bundle: Sol + Mar ($560/night)
- Casa Monkey ($200/night)
- H7 Highlands ($300/night)
- Castillo Colonial (Contact for pricing)

### 3. Netlify Functions (Serverless Backend)

#### `create-reservation.js`
```
POST /api/create-reservation

Input:
- property_id
- guest info (name, email, phone, country)
- check_in, check_out
- num_guests
- payment_method (paypal|wise)
- services (optional concierge array)

Logic:
1. Check availability in blocked_dates table
2. Calculate: nights, accommodation_total, taxes (13%), grand_total
3. Calculate: community_impact (5% of accommodation)
4. Calculate: owner_payout (accommodation * 0.90)
5. Calculate: company_allocation (accommodation * 0.05)
6. Generate unique reference: NCC-YYYYMMDD-XXXX
7. Save to reservations table (status: pending)
8. If PayPal: create PayPal order, return approval_url
9. If Wise: return payment instructions + reference

Output:
{
  reservation_id,
  reference,
  accommodation_total,
  taxes,
  grand_total,
  community_impact,
  payment_method,
  paypal_approval_url (if paypal),
  wise_instructions (if wise)
}
```

#### `paypal-webhook.js`
```
POST /api/paypal-webhook

On payment capture:
1. Verify PayPal signature
2. Update reservation status → 'paid'
3. Block dates in blocked_dates table
4. Send confirmation email to guest
5. Send notification email to admin
```

#### `check-availability.js`
```
GET /api/availability?property_id=X&check_in=Y&check_out=Z

Returns: { available: boolean, blocked_dates: [] }
Also fetches fresh iCal from Airbnb and updates blocked_dates
```

#### `send-confirmation.js`
```
Internal function called after payment confirmed.
Uses Resend.com API (free tier: 3000 emails/month).

Guest email includes:
- Reservation reference
- Property name
- Dates + nights
- Accommodation total
- Taxes
- Grand total
- Community impact generated: $X
- "5% of your stay supports local families in Nosara"
- Check-in instructions
- WhatsApp contact link

Admin email includes:
- All reservation details
- Owner payout amount
- Community impact amount
- Company allocation amount
```

### 4. PayPal Integration

Use PayPal JavaScript SDK (client-side) + server validation.

```html
<!-- Load in index.html -->
<script src="https://www.paypal.com/sdk/js?client-id=YOUR_CLIENT_ID&currency=USD"></script>
```

Flow:
1. Guest selects dates → clicks "Reserve Now"
2. Call `/api/create-reservation` → get PayPal order ID
3. Render PayPal buttons
4. On approval: capture payment server-side via webhook
5. Show success screen with reference + community impact

### 5. Wise Integration

Flow:
1. Guest selects dates → selects "Pay with Wise"
2. Call `/api/create-reservation` → get reference
3. Show Wise payment instructions:
   - Account name: Nosara Collective Conscience
   - Amount: $X USD
   - Reference: NCC-YYYYMMDD-XXXX
   - Email: info@nosaracollective.com
4. Guest uploads payment proof (file upload)
5. Reservation saved as 'pending_verification'
6. Admin reviews and approves manually

### 6. Enhanced Booking Modal

Replace current modal with:

```
┌─────────────────────────────────────┐
│  [Property Gallery — swipe]         │
├─────────────────────────────────────┤
│  Casa Arcilla No. 1                 │
│  3 bed · 3 bath · Private pool      │
│                                     │
│  [Calendar — blocked dates red]     │
│                                     │
│  Check-in: ___  Check-out: ___      │
│  3 nights selected                  │
│                                     │
│  ─────────────────────────────────  │
│  Accommodation (3 nights)  $1,500   │
│  Taxes (13% IVA)            $195    │
│  ─────────────────────────────────  │
│  TOTAL                     $1,695   │
│                                     │
│  🌱 Community Impact:        $75    │
│  "5% supports local Nosara families"│
│                                     │
│  Name: ____________                 │
│  Email: ___________                 │
│  Phone: ___________                 │
│  Guests: [1-10]                     │
│                                     │
│  [PayPal Button]                    │
│  [Pay with Wise →]                  │
└─────────────────────────────────────┘
```

### 7. Environment Variables

Create `.env.example`:
```
# Supabase
SUPABASE_URL=
SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# PayPal
PAYPAL_CLIENT_ID=
PAYPAL_CLIENT_SECRET=
PAYPAL_MODE=sandbox  # → production when live

# Wise
WISE_ACCOUNT_NAME=Nosara Collective Conscience
WISE_EMAIL=info@nosaracollective.com

# Resend (emails)
RESEND_API_KEY=

# Admin
ADMIN_EMAIL=info@nosaracollective.com
ADMIN_WHATSAPP=+50612345678

# Cloudinary (images already uploaded)
CLOUDINARY_CLOUD_NAME=dzqgajn3l
```

### 8. netlify.toml

```toml
[build]
  publish = "."
  functions = "netlify/functions"

[[redirects]]
  from = "/api/*"
  to = "/.netlify/functions/:splat"
  status = 200

[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "DENY"
    X-XSS-Protection = "1; mode=block"
    Content-Security-Policy = "default-src 'self' *.cloudinary.com *.paypal.com *.netlify.app"
```

---

## PHASE 2 — After Phase 1 is live and generating bookings

Build these next:

1. **Admin Dashboard** (Netlify Identity + protected route)
   - All reservations table
   - Wise payment approval
   - Revenue reports (gross, owner payout, community impact)
   - Calendar view per property

2. **Stripe** (for US/Canada guests — higher conversion than PayPal)

3. **WhatsApp Business API** (auto confirmation messages)

4. **AI Concierge** (OpenAI API — answers questions about properties)

5. **SEO Landing Pages**
   - /nosara-vacation-rentals
   - /nosara-retreats
   - /surf-lessons-nosara
   - /atv-rental-nosara

6. **Google Analytics 4** tracking:
   - Property views
   - Booking completions
   - PayPal payments
   - WhatsApp clicks
   - Lead captures

---

## PHASE 3 — Scale

1. Interactive Nosara map
2. Guest portal (view reservations, upload Wise proof)
3. Lead magnets (Moving to Nosara Guide PDF)
4. Testimonials system
5. Newsletter (Mailchimp/Resend)
6. Blog/SEO content

---

## IMPORTANT CONSTRAINTS

- Keep ALL existing visual design (colors, fonts, animations)
- Keep Cloudinary image URLs (already working)
- Keep iCal Airbnb sync (already working)
- Keep WhatsApp button (+506XXXXXXXX)
- Keep all 22 concierge services
- Keep shopping cart flow
- Mobile-first — most guests browse on phone
- Fast loading — Cloudinary handles image optimization

---

## PROPERTIES REFERENCE

| Property | Slug | Price/night | iCal |
|----------|------|-------------|------|
| Casa Arcilla No. 1 | arcilla1 | $500 | airbnb.com/calendar/ical/1364560824324105727.ics?t=36ef19af5ed1411085c3ef4d85c0cac3 |
| Casa Arcilla No. 2 | arcilla2 | $450 | airbnb.com/calendar/ical/1364560764925270828.ics?t=9d789399c92d4524a05e2acf1bb6bb29 |
| Casa Ojos Azules | ojosazules | $500 | airbnb.com/calendar/ical/754963035673300946.ics?t=22dc8b6d04e34ca0a78c1ee28c729f19 |
| Casa Sol | sol | $300 | airbnb.com/calendar/ical/1076720749284905534.ics?t=69701c3ff73d47a69f4594ad8e1dd301 |
| Casa Mar | mar | $300 | airbnb.com/calendar/ical/1075348569613326856.ics?t=c902dda31cd34a35995f770e94af9958 |
| Casa Monkey | monkey | $200 | airbnb.com/calendar/ical/32898115.ics?t=a9262281d6374e0f902ef7ff28c45701 |
| H7 Highlands | h7 | $300 | airbnb.com/calendar/ical/1340590425596595717.ics?t=a7ab7730fc8746ebbb8e20aef8ede4c3 |
| Castillo Colonial | castillo | Contact | N/A |

---

## SERVICES REFERENCE (Concierge Builder)

| Service | Price |
|---------|-------|
| Airport Transfer (LIR/SJO) | $190 |
| ATV Rental | $100/day (2 pax) |
| Golf Cart | $140/day (4-6 pax) |
| Car Rental | $140/day |
| Private Chef (min 4hrs) | $50/hr |
| Grocery Service | $20 fee + cost |
| Extra Cleaning | $100/session |
| Surf Lessons | $80/person |
| Tennis Lessons | $90/session/person |
| Muay Thai | $90/session/person |
| Brazilian Jiu Jitsu | $90/session/person |
| Snorkeling Tour | $180/person |
| Fishing Tour | $1,500 (up to 5 pax) |
| Dolphin Watching | $180/person |
| Sunset Trip | $180/person |
| Surf Trip (Ostional/Marbella) | $150/person |
| Surfboard Rental | $30/day |
| Sunset Horseback Riding | $70-120/person |
| In-House Massage | $150/person |
| Private Yoga Class | $80/class |
| Skate Lessons | $100/day/person |
| Buffet Catering | $35/person |
| Custom Experience | Quote |

---

## START HERE — First message to Claude Code

Paste this entire document, then attach `index.html`, then say:

"Start with Phase 1. 
First, audit the index.html and confirm you understand the existing 
structure. Then set up the project folder structure and Supabase schema. 
Ask me for API keys when you need them. 
Do not change any visual design."

---

*Generated for Nosara Collective Conscience — Nosara, Guanacaste, Costa Rica 🇨🇷*
*Travel with purpose. Stay with impact. Surf good waves everyday 🌴✨*
